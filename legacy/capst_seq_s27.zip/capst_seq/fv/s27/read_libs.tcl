add_search_path . /home/install/GENUS211/tools.lnx86/lib/tech -library -both
read_library -liberty -both \
    /home/cmos/capst_seq/saed90nm_typ.lib

